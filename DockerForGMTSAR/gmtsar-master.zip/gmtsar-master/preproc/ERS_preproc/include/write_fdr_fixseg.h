#define SARLEADER_FDR_FIXSEG_WCS                                                                                                 \
	"*********** SAR FDR FIXED SEGMENT ***********\n"                                                                            \
	"A_E_flag  		==>	%.2s\n"                                                                                                     \
	"blank_2  		==>	%.2s\n"                                                                                                      \
	"for_con_doc  		==>	%.12s\n"                                                                                                 \
	"for_con_doc_rev_level	==>	%.2s\n"                                                                                           \
	"file_des_rev_level  	==>	%.2s\n"                                                                                            \
	"softw_rel  		==>	%.12s\n"                                                                                                   \
	"file_number  		==>	%.4s\n"                                                                                                  \
	"file_name  		==>	%.16s\n"                                                                                                   \
	"rec_seq_loc_type_flag  	==>	%.4s\n"                                                                                         \
	"seq_number_loc		==>	%.8s\n"                                                                                                 \
	"seq_number_field_length	==>	%.4s\n"                                                                                         \
	"rec_code_loc_type_flag 	==>	%.4s\n"                                                                                         \
	"rec_code_loc		==>	%.8s\n"                                                                                                   \
	"rec_code_field_length  	==>	%.4s\n"                                                                                         \
	"rec_len_loc_type_flag  	==>	%.4s\n"                                                                                         \
	"rec_len_loc  		==>	%.8s\n"                                                                                                  \
	"rec_len_field_length  	==>	%.4s\n"                                                                                          \
	"reserved_4  		==>	%.4s\n"                                                                                                   \
	"reserved_segment  	==>	%.64s\n\n"

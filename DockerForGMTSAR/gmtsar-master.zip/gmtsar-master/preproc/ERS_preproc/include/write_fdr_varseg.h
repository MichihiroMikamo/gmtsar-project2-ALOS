#define SARLEADER_FDR_VARSEG_WCS                                                                                                 \
	"*********** SAR FDR VARIABLE SEG ***********\n"                                                                             \
	"n_data_set_summ_rec		==>	%.6s\n"                                                                                            \
	"data_set_summ_rec_len		==>	%.6s\n"                                                                                          \
	"n_map_projec_rec		==>	%.6s\n"                                                                                               \
	"map_projec_rec_len		==>	%.6s\n"                                                                                             \
	"n_plat_pos_data_rec		==>	%.6s\n"                                                                                            \
	"plat_pos_data_rec_len		==>	%.6s\n"                                                                                          \
	"n_att_data_rec			==>	%.6s\n"                                                                                                \
	"att_data_rec_len		==>	%.6s\n"                                                                                               \
	"n_rad_data_rec			==>	%.6s\n"                                                                                                \
	"rad_data_rec_len		==>	%.6s\n"                                                                                               \
	"n_rad_comp_rec			==>	%.6s\n"                                                                                                \
	"rad_comp_rec_len		==>	%.6s\n"                                                                                               \
	"n_data_qua_summ_rec		==>	%.6s\n"                                                                                            \
	"data_qua_summ_rec_len		==>	%.6s\n"                                                                                          \
	"n_data_hist_rec			==>	%.6s\n"                                                                                               \
	"data_hist_rec_len		==>	%.6s\n"                                                                                              \
	"n_range_spectra_rec		==>	%.6s\n"                                                                                            \
	"range_spectra_rec_len		==>	%.6s\n"                                                                                          \
	"n_DEM_des_rec			==>	%.6s\n"                                                                                                 \
	"DEM_des_rec_len			==>	%.6s\n"                                                                                               \
	"n_radar_par_update_rec		==>	%.6s\n"                                                                                         \
	"radar_par_update_rec_len	==>	%.6s\n"                                                                                        \
	"n_annotation_data_rec		==>	%.6s\n"                                                                                          \
	"annotation_data_rec_len		==>	%.6s\n"                                                                                        \
	"n_detailed_proc_rec		==>	%.6s\n"                                                                                            \
	"detailed_proc_rec_len		==>	%.6s\n"                                                                                          \
	"n_cal_rec			==>	%.6s\n"                                                                                                     \
	"cal_rec_len			==>	%.6s\n"                                                                                                   \
	"n_GCP_rec			==>	%.6s\n"                                                                                                     \
	"GCP_rec_len			==>	%.6s\n"                                                                                                   \
	"spare_60			==>	%60c\n"                                                                                                      \
	"n_facility_data_rec		==>	%.6s\n"                                                                                            \
	"facility_data_rec_len		==>	%.6s\n"                                                                                          \
	"blanks_288			==>	%288c\n\n"

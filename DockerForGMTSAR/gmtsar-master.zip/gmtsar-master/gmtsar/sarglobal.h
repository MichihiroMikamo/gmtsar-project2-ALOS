/* global variables are initialized here */
#ifndef SARGLOBAL_H
#define SARGLOBAL_H
int verbose = 0; /* controls minimal level of output 	*/
int debug = 0;   /* more output 				*/
#endif           /* SARGLOBAL_H */

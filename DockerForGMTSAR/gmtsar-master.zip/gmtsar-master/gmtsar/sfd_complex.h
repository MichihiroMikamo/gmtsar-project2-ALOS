#ifndef SFD_COMPLEX_H
#define SFD_COMPLEX_H
typedef struct SCOMPLEX {
	short r, i;
} scomplex;
typedef struct FCOMPLEX {
	float r, i;
} fcomplex;
typedef struct DCOMPLEX {
	double r, i;
} dcomplex;
#endif /* SFD_COMPLEX_H */
